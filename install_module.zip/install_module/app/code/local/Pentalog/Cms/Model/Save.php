<?php

class Pentalog_Cms_Model_Save
{
	public function saveCmsData($data, $storeId) {
		$model = Mage::getModel('cms/block');
		$collection = $model->getCollection()
		                    ->addFieldToFilter('identifier', $data['identifier'])
		                    ->addStoreFilter($storeId);
		$cmsItem = $collection->getFirstItem();

		if ($cmsItem && ($cmsItem->getBlockId())) {
			$oldData = $cmsItem->getData();
			$data = array_merge($oldData, $data);
			$cmsItem->setData($data)->save();
		} else {
			$model->setData($data)->save();
		}
		return;
	}
}