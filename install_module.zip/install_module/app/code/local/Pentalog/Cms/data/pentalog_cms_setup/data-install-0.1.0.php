<?php
/**
 * Define the blocks info
 */
$cmsBlocks = array(
	array(
		'title'         => 'Block Test 1',
		'identifier'    => 'block-test-1',
		'content'       => '<div> <p>test</p></div>',
		'is_active'     => 1,
		'stores'        => 1
	),
	array(
		'title'         => 'Block Test 2',
		'identifier'    => 'block-test-2',
		'content'       => '<div> <p>test 2</p></div>',
		'is_active'     => 1,
		'stores'        => 1
	)
);
/**
 * Insert blocks
 */
foreach ($cmsBlocks as $data) {
	Mage::getModel('cms/block')->setData($data)->save();
}
